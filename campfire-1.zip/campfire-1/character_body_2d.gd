extends CharacterBody2D


const SPEED = 30.0
const JUMP_VELOCITY =  -250.0

var gravity = ProjectSettings.get_setting("physics/2d/default_gravity")
var cAnim: String = "idle"
#jelenlegi animacio

@onready var animated_sprite = $AnimatedSprite2D
@onready var Coyote: Timer = $Coyote

var coyote_time_activated: bool = false
var isPressingSpace: bool = false
var is_jumping: bool = false

func _ready():
		animated_sprite.play("idle")

func _physics_process(delta):
	# Add the gravity.
	if not is_on_floor():
		velocity += get_gravity() * delta

	if coyote_time_activated:
		coyote_time_activated = false
		Coyote.stop()
	else:

		if !coyote_time_activated:
			Coyote.start()
			coyote_time_activated = true	
		

	# Handle jump.
	if Input.is_action_just_pressed("ui_accept"):
		if is_on_floor():
			is_jumping = true
			velocity.y = JUMP_VELOCITY
			isPressingSpace = true

	# Get the input direction and handle the movement/deceleration.
	# As good practice, you should replace UI actions with custom gameplay actions.
	var direction := Input.get_axis("ui_left", "ui_right")
	if direction:
		velocity.x = direction * SPEED
		if not is_jumping:
			cAnim = "walk"
			#animated_sprite.play("walk")
	else:
		velocity.x = move_toward(velocity.x, 0, SPEED)
		if not is_jumping:
			cAnim = "idle"
			#animated_sprite.play("idle")
	if is_jumping == true:
		cAnim = "jump"
		#animated_sprite.play("jump")

#flip
	if direction < 0:
		animated_sprite.flip_h = false
	elif direction > 0:
		animated_sprite.flip_h = true

	if self.is_on_floor() and not isPressingSpace:
		is_jumping = false

	isPressingSpace = false

	animated_sprite.play(cAnim)
	move_and_slide()
