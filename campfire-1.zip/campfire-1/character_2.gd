extends CharacterBody2D

@export var player_id : int = 2

const SPEED = 30.0
const JUMP_VELOCITY = -250.0

var gravity = ProjectSettings.get_setting("physics/2d/default_gravity")
var cAnim: String = "idle"
#jelenlegi animacio

@onready var animated_sprite = $AnimatedSprite2D
@onready var Coyote: Timer = $Coyote

var coyote_time_activated: bool = false
var isPressingSpace: bool = false
var is_jumping: bool = false

func _ready():
	animated_sprite.play("idle")


func _physics_process(delta):

	#gravity
	if not is_on_floor():
		velocity += get_gravity() * delta
	#reset jump when landing
	else:
		is_jumping = false

	var left_action  = "p2_left" % player_id
	var right_action = "p2_right" % player_id
	var jump_action  = "p2_jump" % player_id

	#jump
	if Input.is_action_just_pressed(jump_action):
		if is_on_floor():
			velocity.y = JUMP_VELOCITY
			is_jumping = true
	
	#movement
	var direction := Input.get_axis(left_action, right_action)

	if direction != 0:
		velocity.x = direction * SPEED
		if not is_jumping:
			cAnim = "walk"
	else:
		velocity.x = move_toward(velocity.x, 0, SPEED)
		if not is_jumping:
			cAnim = "idle"

	if is_jumping:
		cAnim = "jump"

	#flip
	if direction < 0:
		animated_sprite.flip_h = false
	elif direction > 0:
		animated_sprite.flip_h = true

	#if animated_sprite.animation != cAnim:
	
	animated_sprite.play(cAnim)
	move_and_slide()
